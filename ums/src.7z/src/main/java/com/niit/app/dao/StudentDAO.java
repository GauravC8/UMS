package com.niit.app.dao;

import java.util.List;

import com.niit.app.model.Student;

public interface StudentDAO {

	public List<Student> getStudents();
	public Student getStudent(String emailId);
	public void deleteStudent(String emailId);
	public void saveStudent(Student student);
}