
package com.niit.app.service;
import com.niit.app.model.User;
public interface UserService {

	public User checkUser(User theUser);
	
}
